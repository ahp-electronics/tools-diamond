1. Test environment:
   1) DUT: RLDRAM memory controller core (instance name: rldram_top)
      configuration:
      SPEED=200
      MODE=RLDRAM-II CIO
      DATA_WIDTH=18
      CONFIG=2
      TMRSC=6
      TRC=6
      TRL=6
      TWL=7
      TREFI=755
      BURST_LENGTH=2
      ADDRESS_WIDTH=21
      NUM_CS=1
      NUM_QK=1
      NUM_DK=1
      AMUX=0
      MACO_LOC=LB
      BANK_ADDRESS=3

   2) Other Instances in the evaluation's testbenches:
      - monitor: (1) Compares the address (row and column) at the FF interface with the address seen on the memory interface.
                 (2) Compares the bank address at the FF interface with the ba[1:0] signals and the chip select assertion at the memory interface.
                 (3) On a write operation, compares the data presented at the FF interface with the data written into the memory.
                 (4) On a read operation, compares the data presented at the memory interface with the data presented at the FF interface.
                 (5) Monitors the bank management function.
                 (6) Monitors X-propagation

2. Sequence of opeartion:
   This test checks for Continuous Writes, cont. Reads and Write followed by Read ...for diff benks and Same bank



3. Waveform description:
   TBD
   
	
4. Instruction to simulate other configurations:
     - Simulation environment supports other configurations:  No
     - For other configuration memory connections to be made accordingly in the testbench.

  Follow this guideline to select the Address width in the GUI (based on Data width)
#######################################################################################
#---------------------------------------------------------------------
# ADDR Width address width of the RLDRAM Memory in bits
#     Memory            Data Width      Address_width 
# for RLDRAMI          16Mx  16          Addr = 20
# for RLDRAMI          8Mx   32          Addr = 19

# for RLDRAMII CIO     32Mx  9           Addr = 22 
# for RLDRAMII CIO     16Mx  18          Addr = 21 
# for RLDRAMII CIO     8Mx   36          Addr = 20
# for RLDRAMII CIO     8Mx   72          Addr = 19
# for RLDRAMII CIO     8Mx   144         Addr = 21 

# for RLDRAMII SIO     32Mx  9           Addr = 21 
# for RLDRAMII SIO     16Mx  18          Addr = 20 
# for RLDRAMII SIO     16Mx  36          Addr = 20 
# for RLDRAMII SIO     16Mx  72          Addr = 20 
# for RLDRAMII SIO     16Mx  144         Addr = 20 
#---------------------------------------------------------------------
